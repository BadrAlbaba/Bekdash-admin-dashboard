export interface ProductImage {
  id: string;
  url: string;
}
