export interface Category {
  id: string;
  name: string;
  level: string;
  parentId?: string;
}
