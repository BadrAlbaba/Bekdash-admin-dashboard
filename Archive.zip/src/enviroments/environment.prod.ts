export const environment = {
  production: true,
  GRAPHQL_API: 'https://yourdomain.com/graphql', // TODO: replace with your production GraphQL API endpoint
};
