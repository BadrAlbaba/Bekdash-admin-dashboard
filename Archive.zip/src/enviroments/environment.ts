export const environment = {
  production: false,
  GRAPHQL_API: 'http://localhost:4000/graphql',
};
